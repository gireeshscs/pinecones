<?php 
/**
 * @file
 * views rows
 */
?>
<?php
  if($rows) {
    print $rows;
  }
?>
<?php
die('www');